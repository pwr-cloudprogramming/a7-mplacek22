﻿namespace TicTacToeCloud.Models
{
    public enum GameStatus
    {
        New,
        InProgress,
        Finished
    }
}
