﻿namespace TicTacToeCloud.Models
{
    public enum TicToe
    {
        X = 1,
        O = 2 
    }
}
