﻿namespace TicTacToeCloud.Models
{
    public class Player
    {
        public string Login {  get; set; }
    }
}
